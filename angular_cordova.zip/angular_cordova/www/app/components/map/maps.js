hackathon.controller("MapController", function(shared, $state, $scope, $mdSidenav, $mdComponentRegistry) {
	

})