hackathon.controller("ProductController", function(shared, $state, $scope, $mdSidenav, $mdComponentRegistry) {
	$scope.productWidth = screen.width - (167)

})