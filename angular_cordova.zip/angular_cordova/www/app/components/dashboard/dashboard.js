hackathon.controller("DashboardController", function(shared, $state, $scope, $mdSidenav, $mdComponentRegistry) {
	

})