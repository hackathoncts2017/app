
(function(){
  'use strict';

  	angular.module('ngapp').controller('firstaidController',['$scope','$timeout','$rootScope','$window',function($scope,$timeout,$rootScope,$window){
  				
		
	}])
  })();
		